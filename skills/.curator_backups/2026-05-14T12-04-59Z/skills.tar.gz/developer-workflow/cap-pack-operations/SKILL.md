---
name: cap-pack-operations
description: "Hermes Capability Pack 提取与维护操作指南 — 从 skill 提取到合并决策到后置质量升级的完整 SOP。基于 hermes-cap-pack 项目实战经验。"
version: 1.5.0
author: "boku (Emma)"
triggers:
  - 能力包提取
  - cap-pack extraction
  - 模块提取
  - 技能包提取
  - 能力包合并
  - cap-pack merge
  - 三层改造
  - three-layer transformation
  - cap-pack quality
  - 能力包健康度
  - skill pack extract
  - pack extraction
  - 提取能力包
  - 创建能力包
  - 知识库合并
  - knowledge-base merge
  - CI 失败
  - CI failure
  - 状态不一致
  - project-state sync
  - 版本不一致
  - validate-readme
metadata:
  hermes:
    tags: [cap-pack, extraction, operations, devops, workflow]
    category: developer-workflow
    skill_type: workflow
    design_pattern: pipeline
depends_on:
  - sdd-workflow
  - doc-alignment
  - project-report-generator
  - skill-creator
---

# 📦 Capability Pack 提取与维护操作指南

> 基于 hermes-cap-pack 项目多次提取实战提炼的标准化流程。
> **核心理念**: 串行执行，每个模块提取后验证+对齐，再进入下一个。

---

## 一、提取流程 (Extraction SOP)

### 串行执行铁律

> 🚨 **每次只做一个模块**。完成 → 验证 → 对齐报告 → commit → 再进入下一个。
> 用户明确要求"串行执行保证质量"——禁止并行提取多个模块。

### 高效批量模式（"继续"工作流）

> 当用户对已建立的工作流只说"继续"时，进入批量高效模式。

**交互模式**: 每完成一个模块，用户回应"继续"即启动下一个。无需汇报摘要、等待明确批准、或询问下一步——直接执行。

**模块顺序**: 按当前 Phase 优先级执行。在菜单式提示中提供下一模块名称让用户确认（如"继续 next-module 喵？"），用户回"继续"视为确认。

**每模块时间盒**: 大模块（5+ skills）~10 min，小模块（1-2 skills）~5 min。快速执行不拖延。

**产出原则**:
- 只提交 **实质性变更**（新 pack 目录 + 项目报告更新）
- 不创建中间状态文件或暂存 commit
- 每次提取后立即 push，保持远端同步

**批量完成清单**（每模块）:
- [ ] 创建目录 + 复制 SKILL.md + linked files
- [ ] 创建 experiences（3-5 个）
- [ ] 创建/更新 cap-pack.yaml
- [ ] Schema 验证通过
- [ ] 更新 PROJECT-PANORAMA.html（KPI + 卡片 + 剩余行）
- [ ] 更新 EPIC-003-module-extraction.md
- [ ] 更新 EPIC-003-comprehensive-roadmap.md
- [ ] 🆕 运行提取完成仪式: `python3 scripts/complete-extraction.py <module>`
- [ ] 🆕 运行推送前门禁: `bash scripts/pre-push.sh`
- [ ] commit + push

### 标准 10 步流程

```
Step 1 ── 创建 Story 文档
   写入 docs/stories/STORY-3-{n}.md
   包含 AC: schema 验证通过 + 报告同步更新

Step 2 ── 盘点技能
   确认 Hermes ~/.hermes/skills/ 中实际存在的 skill
   检查 skill 目录结构（有 SKILL.md 才算有效）
   注意复合 skill（子目录 references/scripts/templates/checklists 要完整复制）

Step 3 ── 复制 SKILL.md + linked files
   mkdir -p packs/<name>/SKILLS/<skill>/
   cp ~/.hermes/skills/<category>/<skill>/SKILL.md ...
   保留子目录引用文件: references/ scripts/ templates/ checklists/
   检查每个 skill 的 linked_files 列表（via skill_view()），确保完整复制

Step 4 ── 创建 Experiences
   每个包创建 3-5 个 experiences（pitfall / decision-tree / comparison）
   来源: skill 中的 Red Flags 章节、已知问题、常见错误模式
   输出到 packs/<name>/EXPERIENCES/<skill>-<type>.md

Step 5 ── 创建 cap-pack.yaml
   严格遵循 cap-pack-v2.schema.json 格式
   skills[] 中每项填入 id/name/description/path/version/tags/sqs_target
   experiences[] 中每项填入 id/name/description/path/type

Step 6 ── Schema 验证
   cd ~/projects/hermes-cap-pack
   python3 -c "import json, yaml, jsonschema; ..."
   必须通过才能继续

Step 7 ── 更新 project-report.json
   新增 architecture.modules[] 条目
   新增 EPIC-003 stories[]
   更新 overview_cards 中的能力包计数
   更新 info_table 中的覆盖率百分比

Step 8 ── 更新项目文档 (×3)
   ① docs/EPIC-003-module-extraction.md
      → 在模块表中添加 ✅ 已提取 标记
   ② docs/plans/EPIC-003-comprehensive-roadmap.md
      → 全景表: ⬜ → ✅
      → Story 行: 状态更新为 ✅ 已提取
   ③ PROJECT-PANORAMA.html
      → 新增能力包卡片
      → 更新 KPI 卡片（能力包数 + 覆盖率）
      → 更新"剩余模块待提取"行
      → 更新 section 标题中的 Pack 计数
      ⚠️ 这是强制步骤 — doc-alignment skill 已写入门禁铁律
   ④ docs/project-state.yaml — 状态机同步
      → 🆕 运行 `python3 scripts/complete-extraction.py <module>`（自动更新 state + Story doc）
      → 然后 `python3 scripts/project-state.py verify` 确认通过
      → 🔴 不执行此步会导致 CI 的 project-state verify 失败！

Step 9 ── 验证无残留引用
   grep -rn "旧模块名" docs/ packs/ README.md | grep -v "合并注释" || echo "✅"

Step 10 ── 本地 CI 预检（🆕 升级为 pre-push.sh）
   bash scripts/pre-push.sh   # 四道门禁: README + project-state + cross-ref + YAML
   # 全部 ✅ → 可以提交
   # 任何 ❌ → 修复后重试

Step 11 ── Commit & Push
   git add -A
   git commit -m "feat: <module> 能力包提取 (N skills, M experiences)
   项目报告同步: PROJECT-PANORAMA.html + EPIC-003 + 全景路线图"
   git push origin main
```

### Experience 创建模式

每个能力包应该包含 3-5 个 experiences，它们是技能的"实战记忆"。来源：

| 来源 | 示例 | 类型 |
|:-----|:------|:-----|
| SKILL.md 的 Pitfalls 章节 | "安装时缺依赖" → `type: pitfall` | pitfall |
| 已知限制/已知问题 | "GPU 不够用" → `type: pitfall` | pitfall |
| 工具对比/选型决策 | "WeasyPrint vs ReportLab" → `type: decision-tree` | decision-tree |
| 性能/配置经验 | "Java 版本与 MC 版本对照" → `type: pitfall` | pitfall |

**Frontmatter 模板**:
```markdown
---
type: pitfall                   # pitfall | decision-tree | comparison
skill_ref: <skill-id>           # 关联的主导 skill
keywords: [tag1, tag2, tag3]    # 搜索发现用
---

# 标题

## 要点表格（推广使用表格而非段落）
| 场景 | 问题 | 解决 |
|:-----|:------|:------|

## 如果适用: 代码块或配置示例
```

**命名**: `<skill>-<topic>.md`，全部小写、连字符分隔。
**位置**: `packs/<name>/EXPERIENCES/`。

**经验与技能的关系**: 经验不是技能的替代——技能说"怎么做"，经验说"什么场景用什么、有什么坑"。两者互补。

### 模块编号规则

> 编号对应 `docs/plans/EPIC-003-comprehensive-roadmap.md` 中的 Story 分配。
> 批量提取时按 Phase 顺序执行，Phase 内可灵活排序。

| Phase | Story ID | 模块 | 状态 |
|:-----:|:---------|:-----|:----:|
| P0 | STORY-3-1 | developer-workflow | ✅ |
| P0 | STORY-3-2 | agent-orchestration | ✅ |
| P0 | STORY-3-3 | metacognition | ✅ |
| P1 | STORY-3-4 | learning-engine | ✅ |
| P1 | STORY-3-5 | quality-assurance | ✅ |
| P1 | STORY-3-6 | creative-design | ✅ |
| P1 | STORY-3-7 | skill-quality | ✅ |
| P2 | STORY-3-8 | devops-monitor | ✅ |
| P2 | STORY-3-9 | security-audit | ✅ |
| P2 | STORY-3-10 | media-processing | ✅ |
| P2 | STORY-3-11 | mcp-integration | ⬜ |
| P3 | STORY-3-12 | network-proxy | ✅ |
| P3 | STORY-3-13 | news-research | ⬜ |
| P3 | STORY-3-14 | financial-analysis | ✅ |
| P3 | STORY-3-15 | social-gaming | ✅ |

> 若全景路线图更新，以 EPIC-003-comprehensive-roadmap.md 为准。

---

## 二、模块合并决策 (Merge Decision)

### 何时应该合并而不是单独提取

当以下条件满足时，应将模块合并到现有包而不是单独提取：

| 条件 | 示例 |
|:-----|:------|
| 核心技能已被其他包吸收 | knowledge-precipitation, knowledge-routing 已在 learning-engine |
| 消除循环依赖 | learning-engine 依赖 knowledge-base，但 knowledge-base 也依赖 learning 方法论 |
| 剩余独特技能 < 4 个 | 合并后 learning-engine 从 ~7→~11 skills |

### 合并操作清单

1. 更新吸收方 cap-pack.yaml：移除对原模块的依赖
2. 更新 SPEC-1-1 模块表：删除被合并行，更新技能数
3. 更新所有交叉引用（EPIC-003, README, SPEC-3-3 等）
4. 每处标注合并原因脚注 `[^1]`
5. 模块体系数更新（如 18+3 → 17+3）

---

## 三、质量升级阶段 (EPIC-004)

全部模块提取完成后，执行 EPIC-004 定义的三阶段升级：

### Phase A: 三层改造
每个包从仅 L1 Skills 升级为三层：
- `EXPERIENCES/` (L2): 实战经验/教训/最佳实践
- `KNOWLEDGE/` (L3): 概念/实体/摘要

### Phase B: 健康度检测
```bash
python3 scripts/skill-quality-score.py --audit --json
python3 scripts/skill-tree-index.py --health
```
目标: CHI ≥ 0.85, SQS 均分 ≥ 80

### Phase C: 合并/清理
```bash
python3 scripts/skill-tree-index.py --consolidate
```
识别重叠 → 合并 → 删除低分废弃 skill

---

## 四、常见陷阱 (Pitfalls)

### ❌ JSON 数组 patch 时引入 `}]` 语法错误
- **症状**: `json.decoder.JSONDecodeError: Expecting ',' delimiter` 在 project-report.json 的 `modules[]` 或 `stories[]` 数组末尾
- **根因**: 当向 JSON 数组追加最后一个元素时，patch 替换内容末尾容易残留 `}]`（本应只有 `}`）
- **避免**: 
  ```python
  # bad: 追加元素时末尾带 ] 会破坏 JSON
  old: ..."last-item"}]
  new: ..."last-item"},
        ..."new-item"}]
  
  # good: 分两步 — 先加元素（只补 }），再让原数组的 ] 自然闭合
  old: ..."last-item"}
  new: ..."last-item"},
        ..."new-item"}
  ```
- **修复**: 如果已经 break，用 patch 把 `...\"new-item\"}]` 中的 `}]` 改回 `}`

### ❌ skill ID 以数字开头违反 schema 模式
- **症状**: `jsonschema.exceptions.ValidationError: '1password' does not match '^[a-z][a-z0-9-]+$'`
- **根因**: v2 schema 要求 skill `id` 以小写字母开头（`^[a-z]`），数字开头的 ID 不通过
- **修复**: 将 `id: 1password` 改为 `id: op-1password`（或其他合法前缀）
- **预防**: 创建 cap-pack.yaml 时检查每个 id 是否匹配 `^[a-z][a-z0-9-]+$`

### ❌ 跳过 HTML 报告对齐
- **后果**: HTML 报告与项目状态不同步，成为过时快照
- **解决**: doc-alignment 已写入强制门禁——每次修改必须更新 HTML

### ❌ 提取后忘记同步 project-state.yaml
- **症状**: CI 的 cross-ref check 报错「状态不一致 (N)」，如 `STORY X: YAML=implemented, DOC=approved 状态不一致`
- **根因**: 提取模块时更新了 EPIC 文档和全景图，但 `docs/project-state.yaml` 状态机文件未同步
- **修复**: 
  ```bash
  python3 scripts/project-state.py sync   # 从 doc 同步到 YAML
  python3 scripts/project-state.py verify  # 确认一致性
  ```
- **预防**: 在 Step 8 中增加子步骤 ④，每次提取后强制同步

### ❌ README/pyproject.toml 版本不一致
- **症状**: CI 的 validate-readme 门禁报 blocking 错误「版本不一致: README=X, pyproject.toml=Y」
- **根因**: README 头部版本号（`**版本**: `\`0.9.0\``）与 `pyproject.toml` 的 `version = "x.x.x"` 不同步
- **修复**: 将较旧的一方更新为与较新一方一致。README 反映项目里程碑，pyproject.toml 反映正式版本
  ```bash
  grep 'version' README.md | head -1
  grep 'version =' pyproject.toml
  ```
- **预防**: Step 10 本地 CI 预检中包含 `python3 scripts/validate-readme.py`，提交前发现

### ❌ 跳过项目文档同步
- **后果**: EPIC-003 模块提取表和全景路线图与实际状态不同步，CI 的 cross-ref check 可能失败
- **解决**: 每次提取后更新 3 份文档: EPIC-003-module-extraction.md, EPIC-003-comprehensive-roadmap.md, PROJECT-PANORAMA.html

### ❌ 多个模块并行提取
- **后果**: 验证遗漏、报告不同步、commit 混乱
- **解决**: 串行执行，一个完成再开始下一个

### ❌ 编号跳步
- **后果**: Story 编号不连续，全景报告中遗漏
- **解决**: 按预分配的 STORY ID 表顺序使用

### ❌ 模块间技能归属判断错误
- **后果**: 同一技能出现在多个包中，造成冗余
- **解决**: 提取前用 skill-tree-index.py --consolidate 检查重叠

### ❌ 复合 skill 的子目录遗漏
- **场景**: feishu 含 feishu-send-file 子 skill + references/ + scripts/ + templates/ + checklists/
- **后果**: 只复制 SKILL.md 导致子 skill 和资源文件丢失
- **解决**: 提取时用 `shutil.copytree()` 或逐个复制子目录，保持完整结构
